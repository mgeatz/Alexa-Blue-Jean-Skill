'use strict';
var Alexa = require('alexa-sdk');
//OPTIONAL: replace with "amzn1.echo-sdk-ams.app.[your-unique-value-here]";
var APP_ID = "amzn1.ask.skill.2262ea28-3c82-4259-b13f-1a02699133e0";
var SKILL_NAME = 'Holiday';

/**
 * Array containing Holiday.
 */
var FACTS = [
  "New Years Day is January first",
  "Martin Luther King Day is January eighteenth",
  "Presidents Day is February fifteenth",
  "Emancipation Day is April fifteenth",
  "Mothers Day is May eight",
  "Memorial Day is May thirtyith",
  "Fathers Day is June nineteenth",
  "Independence Day is July fourth",
  "Labor Day is September fifth",
  "Columbus Day is October 10th",
  "Veterans Day is November eleventh",
  "Thanksgiving is November twenty-fourth",
  "Day after Thanksgiving is November twenty-fifth",
  "Christmas Day is December twenty-fifth"
];

exports.handler = function(event, context, callback) {
  var alexa = Alexa.handler(event, context);
  alexa.APP_ID = APP_ID;
  alexa.registerHandlers(handlers);
  alexa.execute();
};

var handlers = {
  'LaunchRequest': function () {
    this.emit('GetFact');
  },
  'GetNewFactIntent': function () {
    this.emit('GetFact');
  },
  'GetNewYearsDay': function () {
    // Get New Years Day
    var newYearsDay = FACT[0];
    // Create speech output
    var speechOutput = newYearsDay;
    this.emit(':tellWithCard', speechOutput, SKILL_NAME, newYearsDay)
  },
  'GetFact': function () {
    // Get a random space fact from the Holiday list
    var factIndex = Math.floor(Math.random() * FACTS.length);
    var randomFact = FACTS[factIndex];

    // Create speech output
    var speechOutput = "Here's your fact: " + randomFact;

    this.emit(':tellWithCard', speechOutput, SKILL_NAME, randomFact)
  },
  'AMAZON.HelpIntent': function () {
    var speechOutput = "You can say tell me a Holiday, or, you can say exit... What can I help you with?";
    var reprompt = "What can I help you with?";
    this.emit(':ask', speechOutput, reprompt);
  },
  'AMAZON.CancelIntent': function () {
    this.emit(':tell', 'Goodbye!');
  },
  'AMAZON.StopIntent': function () {
    this.emit(':tell', 'Goodbye!');
  }
};